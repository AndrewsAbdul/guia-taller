# Guía del taller · instalar como app (versión 6.2)

Con estos archivos la guía se abre desde una dirección web propia, se instala en el teléfono con el ícono del casco, funciona sin internet y se actualiza sola cuando hay conexión.

## Publicar gratis con GitHub Pages (una sola vez)
1. Crea una cuenta en https://github.com (si no tienes).
2. Toca **New repository**. Nombre: `guia-taller`. Déjalo **Public** y crea el repositorio.
   (Es público: no pongas datos privados dentro de los archivos. Tus registros NO van aquí, se guardan solo en tu teléfono.)
3. Toca **uploading an existing file** y sube TODOS los archivos de esta carpeta: index.html, sw.js, manifest.webmanifest y los tres iconos .png. Confirma con **Commit changes**.
4. Ve a **Settings → Pages**. En *Branch* elige `main` y carpeta `/ (root)`. Guarda.
5. En uno o dos minutos aparece tu dirección: `https://TU-USUARIO.github.io/guia-taller/`

## Instalar en el teléfono
- **Android (Chrome):** abre la dirección, espera el aviso "Instalar" o usa el menú ⋮ → **Instalar app**.
- **iPhone (Safari):** botón Compartir → **Añadir a pantalla de inicio**.
Abre la app una vez con internet para que quede guardada; después funciona sin conexión.

## Importante: tus datos
Los datos viven en el navegador de cada dirección. Al abrir la app instalada por primera vez estará vacía: en el archivo anterior ve a **Ajustes → Copia de seguridad** (mejor la **cifrada**), y en la app nueva usa **Restaurar una copia**.

## Actualizar a una versión nueva
Sube el nuevo `index.html` y `sw.js` a GitHub (reemplazando los anteriores). La app mostrará el aviso "Hay una versión nueva" y se actualiza con un toque.

## Código QR con la nueva dirección
En la guía: **Compartir → Enlace**, pega tu nueva dirección y se actualiza el código QR y el de las etiquetas de equipos.
